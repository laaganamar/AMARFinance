package com.amar.finance

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max

private val Ink = Color(0xFF101827)
private val Green = Color(0xFF13B981)
private val Muted = Color(0xFF718096)
private val Page = Color(0xFFF4F7FB)
private val Money = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply { maximumFractionDigits = 0 }

data class Entry(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Double,
    val type: String,
    val category: String,
    val date: Long = System.currentTimeMillis()
)

data class Goal(val id: String = UUID.randomUUID().toString(), val name: String, val target: Double, val saved: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AmarApp(this) }
    }
}

private fun loadEntries(context: Context): MutableList<Entry> {
    val raw = context.getSharedPreferences("amar_finance", Context.MODE_PRIVATE).getString("entries", "[]") ?: "[]"
    val out = mutableListOf<Entry>()
    try {
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            out.add(Entry(o.optString("id"), o.optString("title"), o.optDouble("amount"), o.optString("type"), o.optString("category"), o.optLong("date")))
        }
    } catch (_: Exception) {}
    return out
}

private fun saveEntries(context: Context, entries: List<Entry>) {
    val array = JSONArray()
    entries.forEach { e ->
        array.put(JSONObject().put("id", e.id).put("title", e.title).put("amount", e.amount)
            .put("type", e.type).put("category", e.category).put("date", e.date))
    }
    context.getSharedPreferences("amar_finance", Context.MODE_PRIVATE).edit().putString("entries", array.toString()).apply()
}

private fun loadGoals(context: Context): MutableList<Goal> {
    val raw = context.getSharedPreferences("amar_finance", Context.MODE_PRIVATE).getString("goals", "[]") ?: "[]"
    val out = mutableListOf<Goal>()
    try {
        val a = JSONArray(raw)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Goal(o.optString("id"), o.optString("name"), o.optDouble("target"), o.optDouble("saved")))
        }
    } catch (_: Exception) {}
    return out
}

private fun saveGoals(context: Context, goals: List<Goal>) {
    val a = JSONArray()
    goals.forEach { g -> a.put(JSONObject().put("id", g.id).put("name", g.name).put("target", g.target).put("saved", g.saved)) }
    context.getSharedPreferences("amar_finance", Context.MODE_PRIVATE).edit().putString("goals", a.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmarApp(context: Context) {
    var entries by remember { mutableStateOf(loadEntries(context).toList()) }
    var goals by remember { mutableStateOf(loadGoals(context).toList()) }
    var budget by remember {
        mutableDoubleStateOf(context.getSharedPreferences("amar_finance", Context.MODE_PRIVATE).getFloat("budget", 25000f).toDouble())
    }
    var tab by remember { mutableIntStateOf(0) }
    var showEntry by remember { mutableStateOf(false) }
    var showGoal by remember { mutableStateOf(false) }
    var showBudget by remember { mutableStateOf(false) }
    val monthKey = SimpleDateFormat("yyyyMM", Locale.US).format(Date())
    val monthly = entries.filter { SimpleDateFormat("yyyyMM", Locale.US).format(Date(it.date)) == monthKey }
    val income = monthly.filter { it.type == "Income" }.sumOf { it.amount }
    val expenses = monthly.filter { it.type == "Expense" }.sumOf { it.amount }
    val balance = income - expenses

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Ink, background = Page, surface = Color.White)) {
        Scaffold(
            containerColor = Page,
            topBar = {
                TopAppBar(
                    title = { Column { Text("AMAR", color = Color.White, fontWeight = FontWeight.Black); Text("PERSONAL FINANCE", color = Color(0xFFB8C4D8), style = MaterialTheme.typography.labelSmall) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("Analytics") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Flag, null) }, label = { Text("Goals") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.TrendingUp, null) }, label = { Text("Invest") })
                }
            },
            floatingActionButton = {
                if (tab == 0) FloatingActionButton(onClick = { showEntry = true }, containerColor = Green, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Add transaction")
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), income, expenses, balance, budget, monthly, onBudget = { showBudget = true })
                1 -> AnalyticsScreen(Modifier.padding(padding), monthly, income, expenses)
                2 -> GoalsScreen(Modifier.padding(padding), goals, onAdd = { showGoal = true })
                else -> InvestmentScreen(Modifier.padding(padding))
            }
        }
    }

    if (showEntry) EntryDialog(onDismiss = { showEntry = false }, onSave = { title, amount, type, category ->
        entries = (listOf(Entry(title = title, amount = amount, type = type, category = category)) + entries)
        saveEntries(context, entries)
        showEntry = false
    })
    if (showGoal) GoalDialog(onDismiss = { showGoal = false }, onSave = { name, target, saved ->
        goals = goals + Goal(name = name, target = target, saved = saved)
        saveGoals(context, goals)
        showGoal = false
    })
    if (showBudget) BudgetDialog(budget, onDismiss = { showBudget = false }, onSave = {
        budget = it
        context.getSharedPreferences("amar_finance", Context.MODE_PRIVATE).edit().putFloat("budget", it.toFloat()).apply()
        showBudget = false
    })
}

@Composable
private fun PageColumn(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable
private fun HomeScreen(modifier: Modifier, income: Double, expenses: Double, balance: Double, budget: Double, monthly: List<Entry>, onBudget: () -> Unit) {
    PageColumn(modifier) {
        Text("Your money, clearly.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
        Text(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date()), color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MONTHLY BALANCE", color = Color(0xFFB8C4D8), style = MaterialTheme.typography.labelMedium)
                Text(Money.format(balance), color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Column(Modifier.weight(1f)) { Text("Income", color = Color(0xFFB8C4D8)); Text(Money.format(income), color = Color(0xFF5EE6B5), fontWeight = FontWeight.SemiBold) }
                    Column(Modifier.weight(1f)) { Text("Expenses", color = Color(0xFFB8C4D8)); Text(Money.format(expenses), color = Color(0xFFFFA7A7), fontWeight = FontWeight.SemiBold) }
                }
            }
        }
        val pct = if (budget > 0) (expenses / budget).toFloat().coerceIn(0f, 1f) else 0f
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Monthly budget", fontWeight = FontWeight.Bold, color = Ink); Text("${Money.format(expenses)} of ${Money.format(budget)}", color = Muted) }
                    TextButton(onClick = onBudget) { Text("Edit") }
                }
                LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth(), color = if (expenses >= budget) Color(0xFFE34D59) else Green)
                if (expenses >= budget) Text("Budget exceeded. Review your spending.", color = Color(0xFFE34D59), fontWeight = FontWeight.SemiBold)
                else if (pct >= 0.8f) Text("Budget alert: you have used at least 80% of your budget.", color = Color(0xFFB7791F))
                else Text("${(100 - pct * 100).toInt()}% of your budget remains", color = Muted)
            }
        }
        Text("Recent transactions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
        if (monthly.isEmpty()) EmptyMessage("No transactions yet. Tap + to add your first entry.")
        else monthly.take(8).forEach { TransactionRow(it) }
    }
}

@Composable
private fun TransactionRow(e: Entry) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(e.title, fontWeight = FontWeight.SemiBold, color = Ink)
                Text("${e.category} • ${SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(e.date))}", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            Text((if (e.type == "Income") "+" else "−") + Money.format(e.amount), color = if (e.type == "Income") Green else Color(0xFFE05260), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AnalyticsScreen(modifier: Modifier, entries: List<Entry>, income: Double, expenses: Double) {
    PageColumn(modifier) {
        Text("Monthly analytics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
        Text("Based on transactions recorded this month.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Income", income, Green, Modifier.weight(1f))
            MetricCard("Expenses", expenses, Color(0xFFE05260), Modifier.weight(1f))
        }
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Income vs expenses", fontWeight = FontWeight.Bold, color = Ink)
                BarLine("Income", income, max(income, expenses), Green)
                BarLine("Expenses", expenses, max(income, expenses), Color(0xFFE05260))
            }
        }
        Text("Spending by category", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
        val categories = entries.filter { it.type == "Expense" }.groupBy { it.category }.mapValues { it.value.sumOf(Entry::amount) }.toList().sortedByDescending { it.second }
        if (categories.isEmpty()) EmptyMessage("Add expenses to see category totals.")
        categories.forEach { (name, amount) -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = Ink); Text(Money.format(amount), color = Ink, fontWeight = FontWeight.SemiBold) } }
    }
}

@Composable
private fun MetricCard(label: String, amount: Double, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) { Text(label, color = Muted); Text(Money.format(amount), color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) } }
}

@Composable
private fun BarLine(label: String, value: Double, maxValue: Double, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = Ink); Text(Money.format(value), color = Ink, fontWeight = FontWeight.SemiBold) }
        Canvas(Modifier.fillMaxWidth().height(12.dp)) {
            drawRoundRect(Color(0xFFE9EEF5), cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f))
            val width = if (maxValue > 0) size.width * (value / maxValue).toFloat() else 0f
            drawRoundRect(color, size = androidx.compose.ui.geometry.Size(width, size.height), cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f))
        }
    }
}

@Composable
private fun GoalsScreen(modifier: Modifier, goals: List<Goal>, onAdd: () -> Unit) {
    PageColumn(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Savings goals", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Text("Add goal") }
        }
        Text("Give every rupee a purpose.", color = Muted)
        if (goals.isEmpty()) EmptyMessage("Create a goal for an emergency fund, bike, car or trip.")
        goals.forEach { goal ->
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(goal.name, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                        Text("${((goal.saved / goal.target.coerceAtLeast(1.0)) * 100).toInt().coerceIn(0,100)}%", color = Green, fontWeight = FontWeight.Bold)
                    }
                    Text("${Money.format(goal.saved)} saved of ${Money.format(goal.target)}", color = Muted)
                    LinearProgressIndicator(progress = { (goal.saved / goal.target.coerceAtLeast(1.0)).toFloat().coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth(), color = Green)
                }
            }
        }
    }
}

@Composable
private fun InvestmentScreen(modifier: Modifier) {
    var monthly by remember { mutableStateOf("5000") }
    var years by remember { mutableStateOf("10") }
    var rate by remember { mutableStateOf("8") }
    val p = monthly.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val y = years.toIntOrNull()?.coerceIn(1, 50) ?: 1
    val r = rate.toDoubleOrNull()?.coerceIn(0.0, 40.0) ?: 0.0
    val n = y * 12
    val rm = r / 100.0 / 12.0
    val invested = p * n
    val future = if (rm == 0.0) invested else p * ((Math.pow(1.0 + rm, n.toDouble()) - 1.0) / rm) * (1.0 + rm)
    PageColumn(modifier) {
        Text("Investment scenarios", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
        Text("Illustrative calculator — not a forecast or guarantee.", color = Muted)
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                NumberField("Monthly contribution (₹)", monthly) { monthly = it }
                NumberField("Duration (years)", years) { years = it }
                NumberField("Assumed annual return (%)", rate) { rate = it }
                Divider()
                Text("Total contributed", color = Muted)
                Text(Money.format(invested), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                Text("Hypothetical future value", color = Muted)
                Text(Money.format(future), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Green)
                Text("Illustration assumes monthly contributions and a constant nominal annual rate compounded monthly. Actual returns can be negative or differ substantially; taxes, fees and inflation are excluded.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun EmptyMessage(message: String) {
    Card(shape = RoundedCornerShape(16.dp)) { Text(message, Modifier.fillMaxWidth().padding(18.dp), color = Muted) }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = { onChange(it.filter { c -> c.isDigit() || c == '.' }) }, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}

@Composable
private fun EntryDialog(onDismiss: () -> Unit, onSave: (String, Double, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Expense") }
    var category by remember { mutableStateOf("Food") }
    val categories = listOf("Food", "Travel", "Bills", "Shopping", "Health", "Salary", "Other")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add transaction") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Description") }, singleLine = true)
            NumberField("Amount (₹)", amount) { amount = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = type == "Expense", onClick = { type = "Expense" }, label = { Text("Expense") })
                FilterChip(selected = type == "Income", onClick = { type = "Income" }, label = { Text("Income") })
            }
            Text("Category", style = MaterialTheme.typography.labelMedium)
            Column {
                categories.chunked(4).forEach { group -> Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    group.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) }
                } }
            }
        }
    }, confirmButton = { TextButton(onClick = { val a = amount.toDoubleOrNull(); if (title.isNotBlank() && a != null && a > 0) onSave(title.trim(), a, type, category) }, enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun GoalDialog(onDismiss: () -> Unit, onSave: (String, Double, Double) -> Unit) {
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Create savings goal") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Goal name") }, singleLine = true)
            NumberField("Target amount (₹)", target) { target = it }
            NumberField("Already saved (₹)", saved) { saved = it }
        }
    }, confirmButton = { TextButton(onClick = { val t = target.toDoubleOrNull(); val s = saved.toDoubleOrNull() ?: 0.0; if (name.isNotBlank() && t != null && t > 0 && s >= 0) onSave(name.trim(), t, s) }, enabled = name.isNotBlank() && (target.toDoubleOrNull() ?: 0.0) > 0) { Text("Save goal") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun BudgetDialog(current: Double, onDismiss: () -> Unit, onSave: (Double) -> Unit) {
    var value by remember { mutableStateOf(current.toLong().toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Monthly budget") }, text = { NumberField("Budget amount (₹)", value) { value = it } },
        confirmButton = { TextButton(onClick = { val n = value.toDoubleOrNull(); if (n != null && n > 0) onSave(n) }, enabled = (value.toDoubleOrNull() ?: 0.0) > 0) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
