# AMAR Finance — Android source project

This is a native Kotlin + Jetpack Compose Android app starter for offline personal finance tracking.

## Included in this first build
- Offline income and expense entries (saved on this device)
- Monthly income, expenses and balance summary
- Monthly budget amount and warning when expenses reach 80% / exceed the budget
- Savings goals with target and saved amounts
- Transparent investment scenario calculator (illustrative only; no guarantee or financial advice)
- No account login, analytics SDK, or network permission

## Build an APK using only your Android phone

1. Download and extract `AMAR-Android-Source.zip`.
2. In your mobile browser, sign in to GitHub and create a **private repository** named `AMARFinance`.
3. Upload the extracted project files and folders to the repository. Ensure `.github/workflows/build-apk.yml` is included. GitHub's website may require uploading folders' contents rather than the folder itself.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build AMAR Finance APK** and tap **Run workflow** if it did not start automatically.
6. Wait for the workflow to finish successfully. Open the completed run and download the `AMAR-Finance-debug-APK` artifact.
7. Extract the downloaded artifact ZIP on your phone. Tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/file manager.
8. Install only the APK you built from your own repository. This is a debug build, not a Play Store release.

## Important
- This archive is source code and a build workflow, **not a prebuilt APK**.
- A successful GitHub Actions run is required before an APK exists.
- Keep the repository private because it contains your personal project source.
- The first version stores data locally in app preferences. Clearing app data or uninstalling the app can erase entries; export/backup is not yet implemented.
- Investment projections are hypothetical, use a fixed annual rate selected by the user, and do not predict actual returns.
